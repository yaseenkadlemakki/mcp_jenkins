"""
MCP Server for Jenkins Log Extraction
"""
